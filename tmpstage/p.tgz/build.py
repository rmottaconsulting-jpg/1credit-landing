import json, subprocess
PH = json.load(open('phrases.json'))['phrases']
END = 59.5
VOEND = 56.3
SEG = [
    ('s1', 0.0, 0.0, 3.78),
    ('s2', 0.0, 3.78, 11.0),
    ('s3', 0.0, 11.0, 18.1),
    ('s4', 0.0, 18.1, 20.7),
    ('s5', 0.0, 20.7, 27.9),
    ('s6', 0.0, 27.9, 34.7),
    ('s7', 0.0, 34.7, 38.6),
    ('s8', 0.0, 38.6, 48.9),
    ('s9', 0.0, 48.9, VOEND),
]
def dur(f):
    return float(subprocess.check_output(['ffprobe', '-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', f]).decode())
parts = []
for i, (c, ss, a, b) in enumerate(SEG):
    L = b - a
    avail = dur(c + '.mp4') - ss - 0.05
    f = max(1.0, L / avail)
    vf = (f"setpts={f:.4f}*(PTS-STARTPTS),fps=30,scale=1080:1920:flags=lanczos,"
          f"zoompan=z='1+0.04*on/({L*30:.0f})':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)':d=1:s=1080x1920:fps=30,"
          f"trim=duration={L:.3f},setsar=1,eq=contrast=1.05:saturation=1.08")
    subprocess.check_call(['ffmpeg', '-loglevel', 'error', '-y', '-ss', str(ss), '-i', c + '.mp4', '-vf', vf, '-an', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '16', f'p{i}.mp4'])
    parts.append(f'p{i}.mp4')
subprocess.check_call(['ffmpeg', '-loglevel', 'error', '-y', '-loop', '1', '-t', f'{END-VOEND:.3f}', '-i', 'ov/end.png', '-vf', 'fps=30,format=yuv420p,fade=t=in:st=0:d=0.35', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '16', 'pend.mp4'])
parts.append('pend.mp4')
open('list.txt', 'w').write(''.join(f"file '{p}'\n" for p in parts))
subprocess.check_call(['ffmpeg', '-loglevel', 'error', '-y', '-f', 'concat', '-safe', '0', '-i', 'list.txt', '-c', 'copy', 'base.mp4'])

ov = [('ov/hook.png', 0.0, 3.6), ('ov/logo.png', 3.78, VOEND)]
for i, (a, b) in enumerate(PH):
    nxt = PH[i + 1][0] if i + 1 < len(PH) else b + 0.4
    ov.append((f'ov/cap{i:02d}.png', max(0, a - 0.05), min(nxt, b + 0.6) if i + 1 < len(PH) else b + 0.4))
ov += [('ov/c240.png', 24.5, 27.9), ('ov/ccar.png', 28.18, 30.6), ('ov/ctaxa.png', 30.76, 34.6),
       ('ov/cseu.png', 35.9, 38.5), ('ov/c20.png', 39.96, 43.2), ('ov/c500.png', 48.96, 53.5)]
args = ['ffmpeg', '-loglevel', 'error', '-y', '-i', 'base.mp4']
for p, _, _ in ov:
    args += ['-i', p]
args += ['-i', 'vo.mp3', '-i', 'music.m4a']
n = len(ov)
fc, last = [], '0:v'
for k, (p, a, b) in enumerate(ov, start=1):
    out = f'v{k}'
    fc.append(f"[{last}][{k}:v]overlay=0:0:enable='between(t,{a:.2f},{b:.2f})'[{out}]")
    last = out
fc.append(f"[{n+1}:a]apad,atrim=0:{END}[vo]")
fc.append(f"[{n+2}:a]apad,atrim=0:{END},volume=0.13,afade=t=out:st={END-2.5}:d=2.5[mu]")
fc.append("[vo][mu]amix=inputs=2:duration=first:normalize=0,loudnorm=I=-14:TP=-1.5:LRA=11[a]")
args += ['-filter_complex', ';'.join(fc), '-map', f'[{last}]', '-map', '[a]', '-c:v', 'libx264', '-preset', 'medium', '-crf', '19',
         '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', '-t', str(END), 'final.mp4']
subprocess.check_call(args)
print('done', dur('final.mp4'))
